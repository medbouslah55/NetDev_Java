/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.mindspace.entities;

import java.util.Comparator;
import java.util.Date;

/**
 *
 * @author mohamedbouslah
 */
public class Coach extends User implements Comparator<Coach>{

    private int cin;
    public Coach() {
        super();
    }
    public Coach(int cin, String nom, String prenom, String password, String date_naissance, String email, String telephne) {
        super(cin, nom, prenom, password, date_naissance, email, telephne);
    }

    public Coach(String cin, String nom, String prenom, String password, String mmm, String email, String telephone) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public Coach(int cin) {
        super(cin);
    }

    @Override
    public int getCin() {
        return super.getCin(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getNom() {
        return super.getNom(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getPrenom() {
        return super.getPrenom(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getPassword() {
        return super.getPassword(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getDate_naissance() {
        return super.getDate_naissance(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getEmail() {
        return super.getEmail(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getTelephne() {
        return super.getTelephne(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setCin(int cin) {
        super.setCin(cin); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setNom(String nom) {
        super.setNom(nom); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setPrenom(String prenom) {
        super.setPrenom(prenom); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setPassword(String password) {
        super.setPassword(password); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setDate_naissance(String date_naissance) {
        super.setDate_naissance(date_naissance); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setEmail(String email) {
        super.setEmail(email); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setTelephne(String telephne) {
        super.setTelephne(telephne); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        return super.toString(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int compare(Coach o1, Coach o2) {
        return o1.getNom().compareTo(o2.getNom());
    }
    

    
    
    
    
    
}
