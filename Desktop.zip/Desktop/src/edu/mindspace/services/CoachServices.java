/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.mindspace.services;

import edu.mindspace.entities.Coach;
import edu.mindspace.entities.Membre;
import edu.mindspace.tools.MyConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author mohamedbouslah
 */
 public class CoachServices implements IUser<Coach>{

    @Override
    public void ajouter(Coach t) {
        String requete="INSERT INTO Coach(cin,nom,prenom,password,date_naissance,email,telephone)"
               + "VALUES (?,?,?,?,?,?,?)";
        try {
            PreparedStatement pst =
                    new MyConnection().cn.prepareStatement(requete);
            pst.setInt(1, t.getCin());
            pst.setString(2, t.getNom());
            pst.setString(3, t.getPrenom());
            pst.setString(4, t.getPassword());
            pst.setString(5, t.getDate_naissance());
            pst.setString(6, t.getEmail());
            pst.setString(7, t.getTelephne());           
            pst.executeUpdate();
            System.out.println("Coach ajoutee !");

            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }    }

    @Override
    public void supprimer(Coach t) {
        String requete = "DELETE FROM Coach WHERE cin=?";
        try {
            PreparedStatement pst = 
                    new MyConnection().cn.prepareStatement(requete);
            pst.setInt(1, t.getCin());
            pst.executeUpdate();
            System.out.println("Coach Supprimée !");
        } catch(SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public void modifier(Coach t) {
        String requete = "UPDATE Coach SET nom=?,prenom=?  ,email=? ,telephone=? WHERE cin=?";
        try {
            PreparedStatement pst = 
                    new MyConnection().cn.prepareStatement(requete);
            pst.setInt(5, t.getCin());
            pst.setString(1, t.getNom());
            pst.setString(2, t.getPrenom());
            
            pst.setString(3, t.getEmail());
            pst.setString(4, t.getTelephne());           
            pst.executeUpdate();
            System.out.println("Coach Modfié !");
        } catch(SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public ObservableList<Coach> afficher() {
        ObservableList<Coach> list = FXCollections.observableArrayList();
        
        String requete = "SELECT * FROM Coach";
        try {
            
            PreparedStatement pst = 
            new MyConnection().cn.prepareStatement(requete);
            ResultSet rs = pst.executeQuery(requete);
            while (rs.next()) {
                list.add(new Coach(rs.getInt(1), rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7))); 
            }
            
        } catch(SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return list;
    }
    
    @Override
    public List<Coach> userListe() {
        List<Coach> list = new ArrayList<>();
        
        String requete = "SELECT * FROM Coach";
        try {
            
            PreparedStatement pst = 
                    new MyConnection().cn.prepareStatement(requete);
            ResultSet rs = pst.executeQuery(requete);
            while (rs.next()) {
                Coach c =new Coach();
                c.setCin(rs.getInt("cin"));
                c.setNom(rs.getString("nom"));
                c.setPrenom(rs.getString("prenom"));
                c.setPassword(rs.getString("password"));
                c.setDate_naissance(rs.getString("date_naissance"));
                c.setEmail(rs.getString("email"));
                c.setTelephne(rs.getString("telephone"));
                
                
                list.add(c);
            }
            
        } catch(SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return list;
    }

    @Override
    public List<Coach> TrieParNom() {
        List<Coach> list = this.userListe();
        Collections.sort(list, new Coach());
        Collections.reverse(list);
        return list;
        
    }

    @Override
    public Coach ChercherUserParNom(String nom) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

    

    
    
    
}
