/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.mindspace.services;

import edu.mindspace.entities.Membre;
import edu.mindspace.tools.MyConnection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author mohamedbouslah
 */
public class MembreServices implements IUser<Membre>{

    @Override
    public void ajouter(Membre t) {
        String requete="INSERT INTO Membre(cin,nom,prenom,password,date_naissance,email,telephone,taille,poids)"
               + "VALUES (?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement pst =
                    new MyConnection().cn.prepareStatement(requete);
            pst.setInt(1, t.getCin());
            pst.setString(2, t.getNom());
            pst.setString(3, t.getPrenom());
            pst.setString(4, t.getPassword());
            pst.setString(5, t.getDate_naissance());
            pst.setString(6, t.getEmail());
            pst.setString(7, t.getTelephne());
            pst.setDouble(8, t.getTaille());
            pst.setDouble(9, t.getPoids());
            pst.executeUpdate();
            System.out.println("Membre ajoutee !");

            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void supprimer(Membre t) {
        String requete = "DELETE FROM Membre WHERE cin=?";
        try {
            PreparedStatement pst = 
                    new MyConnection().cn.prepareStatement(requete);
            pst.setInt(1, t.getCin());
            pst.executeUpdate();
            System.out.println("Membre Supprimée !");
        } catch(SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public void modifier(Membre t) {
        String requete = "UPDATE Membre SET nom=?,prenom=? ,password=? ,email=? ,telephone=?,taille=? ,poids=? WHERE cin=?";
        try {
            PreparedStatement pst = 
                    new MyConnection().cn.prepareStatement(requete);
            pst.setInt(8, t.getCin());
            pst.setString(1, t.getNom());
            pst.setString(2, t.getPrenom());
            pst.setString(3, t.getPassword());
            pst.setString(4, t.getEmail());
            pst.setString(5, t.getTelephne());
            pst.setDouble(6, t.getTaille());
            pst.setDouble(7, t.getPoids());
            pst.executeUpdate();
            System.out.println("Membre Modfié !");
        } catch(SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }

    @Override
    public ObservableList<Membre> afficher() {
        ObservableList<Membre> list = FXCollections.observableArrayList();
        
        String requete = "SELECT * FROM Membre";
        try {
            
            PreparedStatement pst = 
                    new MyConnection().cn.prepareStatement(requete);
            ResultSet rs = pst.executeQuery(requete);
            while (rs.next()) {
                list.add(new Membre(rs.getInt(1), rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getDouble(8),rs.getDouble(9))); 
            }
            
        } catch(SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return list;
    }
    @Override
    public List<Membre> userListe() {
        List<Membre> list = new ArrayList<>();
        
        String requete = "SELECT * FROM Membre";
        try {
            
            PreparedStatement pst = 
                    new MyConnection().cn.prepareStatement(requete);
            ResultSet rs = pst.executeQuery(requete);
            while (rs.next()) {
                Membre m =new Membre();
                m.setCin(rs.getInt("cin"));
                m.setNom(rs.getString("nom"));
                m.setPrenom(rs.getString("prenom"));
                m.setPassword(rs.getString("password"));
                m.setDate_naissance(rs.getString("date_naissance"));
                m.setEmail(rs.getString("email"));
                m.setTelephne(rs.getString("telephone"));
                m.setTaille(rs.getDouble("taille"));
                m.setPoids(rs.getDouble("poids"));
                
                list.add(m);
            }
            
        } catch(SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return list;
    }

    @Override
    public List<Membre> TrieParNom() {
        List<Membre> list = this.userListe();
        Collections.sort(list, new Membre());
        Collections.reverse(list);
        return list;
    }

    @Override
    public Membre ChercherUserParNom(String nom) {
        List<Membre> list = this.userListe();
        for( int i=0;i<list.size();i++){
            if(list.get(i).getNom().equals(nom))
                return list.get(i);
            System.out.println("utilisateur trouver ");        
        }
        System.out.println("n");
        return null;
    }


    

    
    
    
}
