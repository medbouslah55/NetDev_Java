/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.mindspace.test;

import edu.mindspace.entities.Admin;
import edu.mindspace.entities.Coach;
import edu.mindspace.entities.Membre;
import edu.mindspace.services.AdminServices;
import edu.mindspace.services.CoachServices;
import edu.mindspace.services.MembreServices;
import edu.mindspace.tools.MyConnection;

/**
 *
 * @author mohamedbouslah
 */
public class MainClass {
    public static void main(String[] args) {
        MyConnection mc =new MyConnection();
        
        MembreServices ms = new MembreServices();
        CoachServices cs =new CoachServices();
        AdminServices as =new AdminServices();
        //Membre
        Membre m1= new Membre(23432, "mohamed", "bousleh", "fdhfjd", "1998", "med@med.com", "5455454", 180, 64);
        //ms.ajouter(m1);
        //ms.afficher().forEach(System.out::println);
        //ms.supprimer(m1);
        //Membre m2=new Membre(23432, "med", "nacer", "azerty", "1999", "Khalil", "8437483", 189, 65); //pour modifier
        //ms.modifier(m2);
        //ms.afficher().forEach(System.out::println);
        
        //Coach
        //Coach c1= new Coach(123, "mehdi", "deg", "123", "123", "med", "1234");
        //cs.ajouter(c1);
        //cs.afficher().forEach(System.out::println);
        //ms.afficher().forEach(System.out::println);
        //ms.TrieParNom().forEach(System.out::println);
        
        //Membre m5=new Membre(123, "yassine", "moussa", "edede", "1233", "dee", "32323", 180, 65);
        //ms.ajouter(m5);
//        ms.afficher().forEach(System.out::println);
//        
//        ms.TrieParNom().forEach(System.out::println);
//        System.out.println("=============");
//        //ms.ChercherUserParNom("med");
//        as.afficher().forEach(System.out::println);
            Membre m5 =new Membre(54321, "ahmed", "ahmed", "qerty", "1234", "AZER", "2345", 180, 65);
            //ms.ajouter(m5);
            
            //ms.modifier(m5);
            
            //ms.supprimer(m5);
            cs.afficher().forEach(System.out::println);
            //ms.TrieParNom().forEach(System.out::println);
   }
}
