/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.mindspace.gui;

import edu.mindspace.entities.Membre;
import edu.mindspace.services.MembreServices;
import java.lang.reflect.Member;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.util.Duration;
import javax.mail.Session;
import javax.swing.JOptionPane;
import tray.notification.NotificationType;
import tray.notification.TrayNotification;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;

import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * FXML Controller class
 *
 * @author mohamedbouslah
 */
public class InscriptionMembreController implements Initializable {

    @FXML
    private TextField tf_cin_isc;
    @FXML
    private TextField tf_taille_isc;
    @FXML
    private TextField tf_email_isc;
    @FXML
    private TextField tf_pwd_isc;
    @FXML
    private TextField tf_poids_isc;
    @FXML
    private TextField tf_telephone_isc;
    @FXML
    private TextField tf_prenom_isc;
    @FXML
    private TextField tf_nom_isc;
    @FXML
    private DatePicker dp_date_isc;
    @FXML
    private Button bt_inscri;

    /**
     * Initializes the controller class.
     */
    Connection cn;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
     MembreServices ms=new MembreServices();
    @FXML
    private void Inscription(ActionEvent event) {
        
        Membre m = new Membre();
        String cin = tf_cin_isc.getText();
        m.setCin(Integer.parseInt(cin));
        m.setNom(tf_nom_isc.getText());
        m.setPrenom(tf_prenom_isc.getText());
        String datee = String.valueOf(dp_date_isc.getValue());
        m.setDate_naissance(datee);
        m.setEmail(tf_email_isc.getText());
        m.setPassword(tf_pwd_isc.getText());
        m.setTelephne(tf_telephone_isc.getText());
        String tf_taille = tf_taille_isc.getText();
        m.setTaille(Integer.parseInt(tf_taille));
        String tf_poids = tf_poids_isc.getText();
        m.setTaille(Integer.parseInt(tf_poids));
        
        ms.ajouter(m);
        ///mail
        
//        final String username = "cite.de.la.culturec@gmail.com";
//                final String password = "21039010";
//                
//                
//               
//                 try {
//              Statement stmp = cn.createStatement();
//                     String req2 = "SELECT `email` from Membre where cin='"+m.getCin()+"'";
//        ResultSet resultat = stmp.executeQuery(req2);
//         while(resultat.next()){
//           String to= resultat.getString("email");
//           Properties props = new Properties();
//                props.put("mail.smtp.starttls.enable", "true");
//                props.put("mail.smtp.auth", "true");
//                props.put("mail.smtp.host", "smtp.gmail.com");
//                props.put("mail.smtp.port", "25");
//                
//                Session session = Session.getInstance(props,
//                        new javax.mail.Authenticator() {
//                           
//                            @Override
//                            protected PasswordAuthentication getPasswordAuthentication() {
//                                return new PasswordAuthentication(username, password);
//                            }
//                        });
//           
//            try {
//                    
//                    Message message = new MimeMessage(session);
//                    message.setFrom(new InternetAddress("Bdayen"));
//                    message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
//                    message.setSubject("Email De Confirmation");
//                    message.setText("\n"+"*******Bienvenue         "+m.getNom()+"    votre compte a été activé avec succes merci pour votre confiance *******");
//                    Transport.send(message);
//                    JOptionPane.showMessageDialog(null, "Email sent successfully!");
//                } catch (MessagingException ex) {
//                    JOptionPane.showMessageDialog(null, "Oops something went wrong" + "\n" + ex.getMessage());
//                }
//         }
//           
//         } catch (SQLException ex) {
//             Logger.getLogger(Member.class.getName()).log(Level.SEVERE, null, ex);
//         }
        TrayNotification tray = null;
        tray = new TrayNotification("Compte cree", "Votre compte a ete avec succes ,Merci ", NotificationType.WARNING);
        tray.showAndDismiss(Duration.seconds(7));
        
    }
    
    
    
}
