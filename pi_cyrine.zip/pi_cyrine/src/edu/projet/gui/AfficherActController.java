/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.projet.gui;

import edu.projet.entities.Activite;
import edu.projet.entities.Centre;
import edu.projet.services.ActiviteService;
import edu.projet.services.CentreService;
import edu.projet.tools.MyConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class AfficherActController implements Initializable {

    @FXML
    private TableView<Activite> liste;
    @FXML
    private TableColumn<Activite, String> colNom;
    @FXML
    private TableColumn<Activite, String>  colCat;
    @FXML
    private TableColumn<Activite, String>  colPrix;
    @FXML
    private TableColumn<Activite, String>  colCap;
    @FXML
    private TableColumn<Activite, String>  colDesc;
    @FXML
    private TableColumn<Activite, Date> colDate;
    @FXML
    private TableColumn<Activite, String>  colCentre;
    @FXML
    private TableColumn<Activite, String>  colCoach;
    @FXML
    private Button refrech;
    @FXML
    private Button btnModif;
    @FXML
    private Button btnSupp;
    @FXML
    private TextField ftRechCat;
    @FXML
    private Button rechercheAct;
    @FXML
    private Button triAct;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        this.showActivite();
    } 
    
        
    public ObservableList<Activite> getActList(){
    ObservableList<Activite> l = FXCollections.observableArrayList() ;
    String req ="Select * from activite" ;
       
    ActiviteService as = new ActiviteService() ;
    List<Activite> l2 = as.ActiviteListe() ;
    try {
    int i =0 ;
            while (l2.size()>i) {
                Activite a = new Activite() ;
                
                a.setCategorie_act(l2.get(i).getCategorie_act());
                a.setNom_act(l2.get(i).getNom_act());
                a.setId_act(l2.get(i).getId_act());
                a.setPrix_reservation(l2.get(i).getPrix_reservation());
                a.setDate_act(l2.get(i).getDate_act());
                a.setCapacite(l2.get(i).getCapacite());
                a.setDescription(l2.get(i).getDescription());
                a.setId_centre(l2.get(i).getId_centre());
                a.setId_coach(l2.get(i).getId_coach());
               
               i++;
                l.add(a);
            }
    
    }catch(Exception ex){
    
        System.out.println(ex.getMessage());
    }
    
 
   /* CentreService cs = new CentreService() ;
    l =(ObservableList<Centre>) cs.CentreListe() ;*/
    return l ;
    }
    
    
        
    public void showActivite(){
     ObservableList<Activite> l = getActList() ;
    colNom.setCellValueFactory(new PropertyValueFactory<Activite,String>("nom_act"));

    colCat.setCellValueFactory(new PropertyValueFactory<Activite,String>("categorie_act"));
    colPrix.setCellValueFactory(new PropertyValueFactory<Activite,String>("prix_reservation"));
    colCap.setCellValueFactory(new PropertyValueFactory<Activite,String>("capacite"));
    colDesc.setCellValueFactory(new PropertyValueFactory<Activite,String>("description"));
    colDate.setCellValueFactory(new PropertyValueFactory<Activite,Date>("date_act"));
    
    
    //lezem nafichi esem centre moch nom
    colCentre.setCellValueFactory(new PropertyValueFactory<Activite,String>("id_centre"));
    colCoach.setCellValueFactory(new PropertyValueFactory<Activite,String>("id_coach"));
    liste.setItems(l);
    
    }
    
    
    
    
    
    
    
    

    @FXML
    private void RechrechListe(ActionEvent event) {
          this.showActivite();
    }

    @FXML
    private void UpdateAct(ActionEvent event) {
           Activite a = liste.getSelectionModel().getSelectedItem();
        
        try {
            FXMLLoader loader =
                    new FXMLLoader(getClass().getResource("ModifierAct.fxml"));
            Parent root = loader.load() ;
            ModifierActController md = loader.getController() ;
          
            md.setFtPrix(a.getPrix_reservation());
            //conversion de type date vers string pour qu'il soit accepter par le picker 
            md.setDate_act(a.getDate_act().toString());
            md.setFtcap(a.getCapacite());
            md.setFtCat(a.getCategorie_act());
            md.setFtNomAct(a.getNom_act());
            md.setFtDesc(a.getDescription());
            md.setId_act(a.getId_act());
          
  
             //  ListeCentre.setValue(listcentre.get(getOldSelected).getNom_centre());
            md.setId_centre(a.getId_centre());
           
       
            
            String ch = String.valueOf(a.getId_centre()) ;
            md.setLbIDcentre(ch);
     
            
          Stage stage = new Stage() ;
            stage.setTitle("Modifier activité");
          stage.setScene(new Scene(root)) ;
          stage.show();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
            
    }
    
    

    
    
    
    
    
    
    
    
    

    @FXML
    private void DeletaAct(ActionEvent event) {
           Activite a = liste.getSelectionModel().getSelectedItem();
      liste.getItems().removeAll(liste.getSelectionModel().getSelectedItem()) ;
      ActiviteService ac = new ActiviteService() ;
        ac.supprimerActivite(a);
         JOptionPane.showMessageDialog(null, "Activité supprimée avec succès!");
    }

    @FXML
    private void rechAct(ActionEvent event) {
        String res = ftRechCat.getText() ;
        if(res.isEmpty()){
        
        }else{
         this.showActivitefiltrer(); 
        }
        
        
        
       
    }
    
    
    
    
    
    
      public ObservableList<Activite> getCentreListFiltrer(String categorie){
    ObservableList<Activite> l = FXCollections.observableArrayList() ;
    String req ="Select * from activite" ;
    
    try {
     Statement st = MyConnection.getInstance().getConx().createStatement();
            ResultSet rs = st.executeQuery(req);
            while (rs.next()) {
                Activite a = new Activite() ;
                if(rs.getString("categorie_act").toUpperCase().contains(categorie.toUpperCase()))
                {  a.setCategorie_act(rs.getString("categorie_act"));
                a.setNom_act(rs.getString("nom_act"));
                a.setId_act(rs.getInt("id_act"));
                a.setPrix_reservation(rs.getDouble("prix_reservation"));
                a.setDate_act(rs.getDate("date_act"));
                a.setCapacite(rs.getInt("capacite"));
                a.setDescription(rs.getString("description"));
                a.setId_centre(rs.getInt("id_centre"));
                a.setId_coach(rs.getInt("id_coach"));
            
               
                l.add(a);}
            }
    
    }catch(Exception ex){
    
        System.out.println(ex.getMessage());
    }
    
 
   /* CentreService cs = new CentreService() ;
    l =(ObservableList<Centre>) cs.CentreListe() ;*/
    return l ;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     public void showActivitefiltrer(){
         String res = ftRechCat.getText() ;
         ActiviteService ac = new ActiviteService() ;
     ObservableList<Activite> l =this.getCentreListFiltrer(res) ;
    colNom.setCellValueFactory(new PropertyValueFactory<Activite,String>("nom_act"));
    colCat.setCellValueFactory(new PropertyValueFactory<Activite,String>("categorie_act"));
    colPrix.setCellValueFactory(new PropertyValueFactory<Activite,String>("prix_reservation"));
    colCap.setCellValueFactory(new PropertyValueFactory<Activite,String>("capacite"));
    colDesc.setCellValueFactory(new PropertyValueFactory<Activite,String>("description"));
    colDate.setCellValueFactory(new PropertyValueFactory<Activite,Date>("date_act"));
    
    
    //lezem nafichi esem centre moch id :(
    colCentre.setCellValueFactory(new PropertyValueFactory<Activite,String>("id_centre"));
    colCoach.setCellValueFactory(new PropertyValueFactory<Activite,String>("id_coach"));
    liste.setItems(l);
    
    }

    @FXML
    private void detectChange(ActionEvent event) {
         String res = ftRechCat.getText() ;
        if(res.isEmpty())
            this.showActivite();
        
    }

    @FXML
    private void TriListe(ActionEvent event) {
        
        ActiviteService as = new ActiviteService() ;
        List<Activite> trier = as.CentreActTrierParPrix() ;
        
        ObservableList<Activite> l = FXCollections.observableArrayList() ;
 
    
    try {
    int i=0 ;
            while (trier.size()>i) {
                Activite a = new Activite() ;
              a.setPrix_reservation(trier.get(i).getPrix_reservation());
              a.setId_act(trier.get(i).getId_act());
              a.setNom_act(trier.get(i).getNom_act());
              a.setCapacite(trier.get(i).getCapacite());
              a.setDescription(trier.get(i).getDescription());
              a.setDate_act(trier.get(i).getDate_act());
            a.setId_centre(trier.get(i).getId_centre());
            a.setId_coach(trier.get(i).getId_coach());  
                i++;
           
                l.add(a);
            }
            
            
            colNom.setCellValueFactory(new PropertyValueFactory<Activite,String>("nom_act"));

    colCat.setCellValueFactory(new PropertyValueFactory<Activite,String>("categorie_act"));
    colPrix.setCellValueFactory(new PropertyValueFactory<Activite,String>("prix_reservation"));
    colCap.setCellValueFactory(new PropertyValueFactory<Activite,String>("capacite"));
    colDesc.setCellValueFactory(new PropertyValueFactory<Activite,String>("description"));
    colDate.setCellValueFactory(new PropertyValueFactory<Activite,Date>("date_act"));
    
    
    //lezem nafichi esem centre moch nom
    colCentre.setCellValueFactory(new PropertyValueFactory<Activite,String>("id_centre"));
    colCoach.setCellValueFactory(new PropertyValueFactory<Activite,String>("id_coach"));
    liste.setItems(l); 
            
            
            
    
    }catch(Exception ex){
    
        System.out.println(ex.getMessage());
    }
  
 
        
    }
    
    
    
}
