/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.projet.test;

import edu.projet.entities.Activite;
import edu.projet.entities.Centre;
import edu.projet.services.ActiviteService;
import edu.projet.services.CentreService;
import edu.projet.tools.MyConnection;
import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author DELL
 */
public class MainClass {
    public static void main(String[] args) {
        MyConnection mc = MyConnection.getInstance();
      Centre c1 = new Centre("suivie", "suivie", "suivie", "suivie2", "suivie2");
        CentreService cs = new CentreService() ;
        //Ajout d'un centre
        // cs.ajouterCentre2(c1); 
        //cs.ajouterCentre(c1);
        
        
        //Supp par id 
         // cs.supprimerCentre(13); 
         
         
         //Supp par objet Centre
          c1.setId_centre(14);
         cs.supprimerCentre(c1); 
        
        //modif on doit tt dab specifier l'id 
        // c1.setId_centre(14);
        // cs.modifierCentre(c1); 
        
        
        
        //Get La liste des centre
         /* List<Centre> mylist = new ArrayList<Centre>(); 
        mylist = cs.CentreListe() ;
        System.out.println(mylist);*/
       
        
        //Get Centre par id
        /* Centre c = cs.getCentre(2);
        System.out.println(c);*/
        
        //Metier
       // System.out.println(cs.CentreListeTrierParNom());
        //System.out.println(cs.CentreListeTrierParNomReverse());
        //System.out.println(cs.ChercherCentreParNom("Ami"));
        
        
        
        //type date et non pas string
       // Activite ac = new Activite("suivie", "suivie", 5.5,"2020/06/02" , "test", 12, 15 ,0);
      
        ActiviteService as = new ActiviteService() ;
        
        //Ajout d'une act
     //  as.ajouterActivite(ac); 
       
       //supp act par id
      //   as.supprimerActivite(1); cbon
      
      
      //supp act par objet act
      // ac.setId_act(4);
     //  as.supprimerActivite(ac); 
       
       
       
      //update act
      // ac.setId_act(5);
       // as.modifierActivite(ac); 
        
        
        //liste des act
       // System.out.println(as.ActiviteListe()); 
       
       //get act par id 
       // System.out.println(as.getActivite(2));
       
       
       
       
       //metier
       // System.out.println(as.CentreActTrierParPrix()) ;
       // System.out.println(as.ChercherActParCategorie("mental"));
       // System.out.println(as.ChercherActParNom("test"));
       // System.out.println(as.ActListeTrierParPrixReverse());
    
    }
}
